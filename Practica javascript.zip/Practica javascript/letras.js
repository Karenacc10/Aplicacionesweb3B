function calcularLetraDNI() {
    var dni;
  
    do {
      dni = prompt("Introduce el numero de DNI (0 a 99999999):");
  
      if (dni !== null) {
        dni = parseInt(dni);
  
        if (isNaN(dni) || dni < 0 || dni > 99999999) {
          alert("El valor ingresado no es valido.");
        } else {
          var letras = "TRWAGMYFPDXBNJZSQVHLCKE";
          var indice = dni % 23;
          var letra = letras.charAt(indice);
  
          alert("La letra del DNI " + dni + " es: " + letra);
        }
      }
    } while (dni !== null);
  }
  