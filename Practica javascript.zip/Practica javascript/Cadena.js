function solicitarCadenas() {
    var resultado = "";
    
    do {
      var cadena = prompt("Introduce una cadena:");
      
      if (cadena !== null && cadena !== "") {
        if (resultado === "") {
          resultado += cadena;
        } else {
          resultado += "-" + cadena;
        }
      }
    } while (confirm("¿Desea seguir ingresando cadenas?"));
  
    var resultadoElemento = document.getElementById("resultado");
    resultadoElemento.textContent = resultado;
  }
  