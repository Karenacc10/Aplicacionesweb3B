function verificarEdad() {
    var edad = parseInt(prompt("Ingresa tu edad:"));
  
    if (edad >= 18) {
      alert(" ¡Ya puedes conducir !");
    } else {
      alert("Aun no puedes conducir.");
    }
  }
  